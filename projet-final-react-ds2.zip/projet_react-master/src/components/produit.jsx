import prod1 from '/prod1.jpg';
import prod2 from '/prod2.jpg';
import prod3 from '/prod3.jpg';
import prod4 from '/prod4.jpg';
import prod5 from '/prod5.jpg';
import prod6 from '/prod6.jpg';


const Produits =[ 
    
      {
        id:1,
        label:"Assiette en porcelaine",
        price : 60,
        path:prod1
    },

    {
        id:2,
        label:"Tapis",
        price : 230,
        path:prod6
    },


    

    {
        id:3,
        label:"Statue ornementale",
        price : 150,
        path:prod3
    },
    {
        id:4,
        label:"tableau artistique",
        price : 350,
        path:prod4
    },

    {
        id:5,
        label:"Vase en poterie",
        price : 35,
        path:prod5
    },

    {
        id:6,
        label:"Bougie aromatique",
        price : 17,
        path:prod2
    }
];

export default Produits